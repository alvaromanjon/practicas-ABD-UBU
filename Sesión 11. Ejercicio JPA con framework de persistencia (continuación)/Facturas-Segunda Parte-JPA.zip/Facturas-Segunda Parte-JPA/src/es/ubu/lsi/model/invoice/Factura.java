package es.ubu.lsi.model.invoice;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the FACTURAS database table.
 * 
 */
@Entity
@Table(name="FACTURAS")
//@NamedQuery(name="Factura.findAll", query="SELECT f FROM Factura f")
public class Factura implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long nro;

	private String cliente;

	@Temporal(TemporalType.DATE)
	private Date fecha;

	private BigDecimal total;
	
	@Embedded
	private DireccionFacturacion direccionFacturacion;

	//bi-directional many-to-one association to LineaFactura
	@OneToMany(mappedBy="factura")
	private Set<LineaFactura> lineasfacturas;

	public Factura() {
	}

	public long getNro() {
		return this.nro;
	}

	public void setNro(long nro) {
		this.nro = nro;
	}

	

	public String getCliente() {
		return this.cliente;
	}

	public void setCliente(String cliente) {
		this.cliente = cliente;
	}

	
	public Date getFecha() {
		return this.fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public BigDecimal getTotal() {
		return this.total;
	}

	public void setTotal(BigDecimal total) {
		this.total = total;
	}

	public Set<LineaFactura> getLineasfacturas() {
		return this.lineasfacturas;
	}

	public void setLineasfacturas(Set<LineaFactura> lineasfacturas) {
		this.lineasfacturas = lineasfacturas;
	}

	public LineaFactura addLineasfactura(LineaFactura lineasfactura) {
		getLineasfacturas().add(lineasfactura);
		lineasfactura.setFactura(this);

		return lineasfactura;
	}

	public LineaFactura removeLineasfactura(LineaFactura lineasfactura) {
		getLineasfacturas().remove(lineasfactura);
		lineasfactura.setFactura(null);

		return lineasfactura;
	}

}