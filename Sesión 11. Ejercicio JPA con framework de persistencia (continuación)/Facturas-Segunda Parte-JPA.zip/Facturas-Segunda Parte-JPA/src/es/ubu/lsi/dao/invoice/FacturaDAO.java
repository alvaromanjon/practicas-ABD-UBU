package es.ubu.lsi.dao.invoice;

import javax.persistence.EntityManager;

import es.ubu.lsi.dao.JpaDAO;
import es.ubu.lsi.model.invoice.Factura;

/**
 * Factura DAO.
 * 
 * @author <a href="mailto:jmaudes@ubu.es">Jesús Maudes</a>
 * @author <a href="mailto:rmartico@ubu.es">Raúl Marticorena</a>
 * @author <a href="mailto:mmabad@ubu.es">Mario Martínez</a>
 * @since 1.0
 */
public class FacturaDAO extends JpaDAO<Factura, Long> {
	
	/**
	 * Constructor. 
	 * 
	 * @param em entity manager
	 */
	public FacturaDAO(EntityManager em) {
		super(em);
	}
	
	// If we need new methods (not inherited) in this DAO, include here...
}
