package es.ubu.lsi.dao.invoice;

import javax.persistence.EntityManager;

import es.ubu.lsi.dao.JpaDAO;
import es.ubu.lsi.model.invoice.LineaFactura;
import es.ubu.lsi.model.invoice.LineaFacturaId;

/**
 * Línea de factura DAO.
 * 
 * @author <a href="mailto:jmaudes@ubu.es">Jesús Maudes</a>
 * @author <a href="mailto:rmartico@ubu.es">Raúl Marticorena</a>
 * @author <a href="mailto:mmabad@ubu.es">Mario Martínez</a>
 * @since 1.0
 */
public class LineaFacturaDAO extends JpaDAO<LineaFactura,LineaFacturaId> {

	/**
	 * Constructor. 
	 * 
	 * @param em entity manager
	 */
	public LineaFacturaDAO(EntityManager em) {
		super(em);
	}
	
	// If we need new methods (not inherited) in this DAO, include here...
}
