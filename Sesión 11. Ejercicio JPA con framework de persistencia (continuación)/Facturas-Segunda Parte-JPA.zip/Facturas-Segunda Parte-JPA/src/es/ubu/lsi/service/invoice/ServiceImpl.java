package es.ubu.lsi.service.invoice;

import java.math.BigDecimal;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import es.ubu.lsi.dao.invoice.FacturaDAO;
import es.ubu.lsi.dao.invoice.LineaFacturaDAO;
import es.ubu.lsi.model.invoice.Factura;
import es.ubu.lsi.model.invoice.LineaFactura;
import es.ubu.lsi.model.invoice.LineaFacturaId;
import es.ubu.lsi.service.PersistenceException;
import es.ubu.lsi.service.PersistenceService;

/**
 * Transaction service solution.
 * 
 * @author <a href="mailto:jmaudes@ubu.es">Jesús Maudes</a>
 * @author <a href="mailto:rmartico@ubu.es">Raúl Marticorena</a>
 * @author <a href="mailto:mmabad@ubu.es">Mario Martínez</a>
 * @since 1.0
 *
 */
public class ServiceImpl extends PersistenceService implements Service {

	/** Logger. */
	private static final Logger logger = LoggerFactory
			.getLogger(ServiceImpl.class);

	/**
	 * {@inheritDoc}.
	 * @param line {@inheritDoc}
	 * @param nro {@inheritDoc}
	 * 
	 * @throws PersistenceException {@inheritDoc}
	 */
	@Override
	public void borrarLinea(int line, int nro)
			throws PersistenceException {
		EntityManager em = this.createSession();
		try {
			beginTransaction(em);
			
			// Get DAOs
			FacturaDAO facturaDAO = new FacturaDAO(em);
			LineaFacturaDAO lineasFacturaDAO = new LineaFacturaDAO(em);

			// Step 1
			LineaFacturaId id = new LineaFacturaId(line, nro);
			LineaFactura lineaFacturaBorrar = lineasFacturaDAO.findById(id);
			if (lineaFacturaBorrar != null) {
				
				lineasFacturaDAO.remove(lineaFacturaBorrar); // delete línea
				// Step 3
				Factura facturadecrementar = facturaDAO.findById(Long.valueOf(nro));//convertir de int a Long			
				
				if (facturadecrementar != null) {
					int total = facturadecrementar.getTotal().intValue();
					int importe = lineaFacturaBorrar.getImporte().intValue() * lineaFacturaBorrar.getUnidades().intValue();
					int nuevoValor = total - importe;
					facturadecrementar.setTotal(BigDecimal.valueOf(nuevoValor));
				} else {
					logger.error("Factura no encontrada, la integridad referencial no está bien definida.");
					throw new RuntimeException(	"Integridad referencial mal definida en LineasFactura-Factura.");
				}
			} else {
				logger.error("Línea no encontrada.");
				throw new InvoiceException(InvoiceError.NOT_EXIST_INVOICE_LINE);
			}
			commitTransaction(em);
			
		} catch (InvoiceException ex) {
			rollbackTransaction(em);
			logger.error(ex.getLocalizedMessage());
			throw ex;
		} catch (Exception ex) {
			rollbackTransaction(em);
			logger.error(ex.getLocalizedMessage());
			throw new PersistenceException("General error in DB transaction removing invoice line", ex);
		} finally {
			close(em);
			logger.debug("Closing session.");
		} 
		return;
	}
}
