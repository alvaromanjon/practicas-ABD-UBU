package es.ubu.lsi.service.invoice;

import java.util.List;

import es.ubu.lsi.model.invoice.Factura;
import es.ubu.lsi.service.PersistenceException;

/**
 * Transaction service.
 * 
 * @author <a href="mailto:jmaudes@ubu.es">Jesús Maudes</a>
 * @author <a href="mailto:rmartico@ubu.es">Raúl Marticorena</a>
 * @author <a href="mailto:mmabad@ubu.es">Mario Martínez</a>
 * @since 1.0
 *
 */
public interface Service {

	/**
	 * Remove the invoice line.
	 * 
	 * @param p_line invoice line
	 * @param p_nro invoice nro
	 * 
	 * @throws PersistenceException if exists any error
	 */
	public  void borrarLinea(int p_line, int p_nro)
			throws PersistenceException;
	
	/**
	 * Queries the invoice with a total different to the total of their lines.
	 * 
	 * @return list of wrong invoices 
	 * @throws PersistenceException if exists any fail
	 */
	public List<Factura> consultarFacturasDesequilibradas() throws PersistenceException;
}
